from django.apps import AppConfig


class SummarizeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Summarize'
