from django.contrib import admin
from Summarize.models import Summary

# Create your tests here.
admin.site.register(Summary)
